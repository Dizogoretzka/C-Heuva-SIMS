"""student_management_system URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.http import Http404
from django.contrib import admin
from django.urls import path, include
from django.conf.urls.static import static
from . import settings


def unavailable_admin_password_change(request):
    raise Http404


urlpatterns = [
    path(
        'admin/password_change/done/',
        unavailable_admin_password_change,
    ),
    path(
        'admin/password_change/',
        unavailable_admin_password_change,
    ),
    path("", include('main_app.urls')),
    path('admin/', admin.site.urls),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
